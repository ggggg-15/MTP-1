using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class human_left : MonoBehaviour
{
    /*
    // Start is called before the first frame update
    public Rigidbody rb;
    // public float forwardForce = 20f;

    // Update is called once per frame
    void FixedUpdate()
    {
        rb.AddForce(-13, 0, 0);
    }*/


    
    public float moveSpeed = 5f;         // Speed of movement
    public float interval = 10f;          // Time interval for changing direction

    private Rigidbody rb;
    private float timer = 0f;
    private bool movingForward = true;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        // Update the timer
        timer += Time.deltaTime;

        // Check if it's time to change direction
        if (timer >= interval)
        {
            // Reset the timer
            timer = 0f;

            // Toggle the direction
            movingForward = !movingForward;

            // Rotate the Rigidbody 180 degrees around the Y-axis
            transform.Rotate(0, 180, 0);
        }

        // Move the Rigidbody in the current direction
        Vector3 direction = movingForward ? transform.forward : -transform.forward;
        rb.MovePosition(rb.position + direction * moveSpeed * Time.deltaTime);
    }

    /*
    public float moveSpeed = 5f;         // Speed of movement
    public float interval = 2f;          // Time interval for changing direction

    private Rigidbody rb;
    private float timer = 0f;
    private bool movingForward = true;

    void Start()
    {
        rb = GetComponent<Rigidbody>();

        // Start moving forward
        rb.velocity = transform.forward * moveSpeed;
    }

    void Update()
    {
        // Update the timer
        timer += Time.deltaTime;

        // Check if it's time to change direction
        if (timer >= interval)
        {
            // Reset the timer
            timer = 0f;

            // Toggle the direction
            movingForward = !movingForward;

            // Reverse the velocity
            rb.velocity = -rb.velocity;

            // Rotate the Rigidbody 180 degrees around the Y-axis
            transform.Rotate(0, 180, 0);
        }
    }
    */
}
