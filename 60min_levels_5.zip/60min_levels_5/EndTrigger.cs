using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndTrigger : MonoBehaviour
{
    public GameManager Manager;

    private void OnTriggerEnter(Collider car)
    {
        if (car.CompareTag("grey_car_1"))
        {
            Manager.CompleteLevel();
        }
        
    }
}
