using UnityEngine;
using UnityEngine.UI;

public class Speed_display : MonoBehaviour
{
    public Rigidbody player;
    public Text speed;

    // Update is called once per frame
    void Update()
    {
        // speed text will be the speed of the 
        speed.text = "Speed : " + player.velocity.magnitude.ToString("0") + "km/h";

        // spedd mof
    }
}
