using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("ConeMeshEditorAssembly")]
namespace KevinCastejon.ConeMesh { }