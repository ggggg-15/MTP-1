import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QDesktopWidget
from PyQt5.QtCore import QTimer, Qt, QRect
from PyQt5.QtGui import QPixmap
from screeninfo import get_monitors
from Connect import egi_connect
import time
import datetime
import random


    # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
    #                                                                               #
    # Experiment sequence: start --> baseline --> fixation --> trial --> rest --,   #
    #                                                ^                          |   #
    #                                                |      _____________       |   #
    #                                                '-----|no. of trials|------'   #
    #                                                      '-------------'          #
    # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

_TEST = True
# _TEST = False

# Markers
start = '1000'
baseline = '1001'  # 10 seconds
fixation = '1002'  # 2 seconds
marker = '1008'    # 2 seconds
red = '1003'       # 5 seconds
green = '1004'     # 5 seconds
blue = '1005'      # 5 seconds
rest = '1006'      # 5 seconds
stop = '1007'

if _TEST == True:
    samples = 2
    baseline_duration = 2000
    fixation_duration = 2000
    trial_duration = 2000
    rest_duration = 2000
    marker_duration = 1000
else:
    samples = 5    # Number of trials for each class
    baseline_duration = 10000  # 10 seconds
    fixation_duration = 2000  # 2 seconds
    trial_duration = 5000  # 5 seconds
    rest_duration = 4000  # 4 seconds
    marker_duration = 1000  # 1 seconds

class Color(QWidget):
    def __init__(self):
        super().__init__()
        self.title = 'Color Detection'
        self.left = 0
        self.top = 0

        for m in get_monitors():
            self.width = m.width    # Getting width of the stimuli screen
            self.height = m.height  # Getting height of the stimuli screen

        self.setWindowTitle(self.title)
        self.setStyleSheet('Background-color: rgb(128, 128, 128)')
        self.setGeometry(self.left, self.top, self.width, self.height)

        self.cheight = int(self.height*0.3)
        self.cwidth = int(self.width*0.3)

        self.count = 0

        self.Flabel = QLabel('Times font', self)
        self.Flabel.setGeometry(int(self.width/2)-200, int(self.height/2)-200, 400, 400)
        self.Flabel.setStyleSheet('background-color: rgb(128, 128, 128); font-size: 150px; color: rgb(0, 0, 0)')
        self.Flabel.setText("+")
        self.Flabel.setAlignment(Qt.AlignCenter)
        self.Flabel.setVisible(False)

        self.baseline_timer = QTimer(self)
        self.fixation_timer = QTimer(self)
        self.marker_timer = QTimer(self)
        self.trial_timer = QTimer(self)
        self.rest_timer = QTimer(self)

        self.Rlabel = QLabel(self)
        self.Rlabel.setGeometry(20, self.height-self.cheight-20, self.cwidth, self.cheight)
        self.Rlabel.setStyleSheet('background-color: rgb(255, 0, 0)')
        self.Rlabel.setVisible(False)

        self.Glabel = QLabel(self)
        self.Glabel.setGeometry(int(self.width/2)-int(self.cwidth/2), int(self.height/2)-int(self.cheight/2), self.cwidth, self.cheight)
        self.Glabel.setStyleSheet('background-color: rgb(0, 255, 0)')
        self.Glabel.setVisible(False)

        self.Blabel = QLabel(self)
        self.Blabel.setGeometry(self.width-self.cwidth-20, 20, self.cwidth, self.cheight)
        self.Blabel.setStyleSheet('background-color: rgb(0, 0, 255)')
        self.Blabel.setVisible(False)

        self.pos = 0

        self.setCursor(Qt.BlankCursor)

        self.marker_list = [1]*samples + [2]*samples + [3]*samples  #  red: 1,  green: 2,  blue:3
        random.shuffle(self.marker_list)  # Shuffling the marker list

        self.i = 0
        self.event_list = []
        self.session_time = datetime.datetime.now().strftime("%Y_%m_%d_%H_%M_%S")    # capturing the session start time for saving marker file along with timestamp
        if _TEST == True:
            self.filename = 'Events/Experiment_3/events_exp_3_2_' + str(self.session_time) + '_test.txt'  # while testing
        else:
            self.filename = 'Events/Experiment_3/events_exp_3_2_' + str(self.session_time) + '.txt'   # while conducting experiments
    
    def keyPressEvent(self, e):
        print(e.key())
        if e.key() == 16777220: # press enter to call start function and start the session
            if self.count == 0:
                self.start()
                self.count = 1
        if e.key() == 16777216: # press esc to quit the session manually
            print("Experiment Terminated.....")
            # open file in write mode
            self.event_list.append([time.time(), 'end'])
            with open(self.filename, 'w') as fp:
                for item in self.event_list:
                    fp.write("%s,%s\n" % (str(item[0]), item[1]))   # writing events in the file
            fp.close()
            print(self.event_list)
            if _TEST == False:
                egi_connect(stop)   # Sending stop marker
                egi_connect(2)  # Stoping recording
                print("Recording Stopped Manually.....")
                egi_connect(3)  # Stoping amplifier
                print("Amplifier Stopped Manually.....")   
            sys.exit()
    
    def start(self):
        print("Experiment Started.....")
        self.event_list.append([time.time(), 'start'])
        if _TEST == False:
            print("Recording Started.....")
            egi_connect(1)  # Start recording
        self.baseline()

    def baseline(self):
        self.event_list.append([time.time(), 'baseline'])
        if _TEST == False:
            egi_connect(baseline)   # Sending baseline marker
        self.Rlabel.setVisible(False)
        self.Glabel.setVisible(False)
        self.Blabel.setVisible(False)
        self.baseline_timer.singleShot(baseline_duration, self.fixation)


    def fixation(self):
        self.event_list.append([time.time(), 'fixation'])
        if _TEST == False:
            egi_connect(fixation)   # Sending fixation marker
        self.fixation_timer.singleShot(fixation_duration, self.marker)
        self.Flabel.setVisible(True)
        self.Rlabel.setVisible(False)
        self.Glabel.setVisible(False)
        self.Blabel.setVisible(False)
    
    def marker(self):
        if _TEST == False:
            egi_connect(marker)   # Sending marker
        self.marker_timer.singleShot(marker_duration, self.trial)
        self.event_marker()

    def event_marker(self):
        self.Flabel.setVisible(False)
        if self.i < len(self.marker_list):
            if self.marker_list[self.i] == 1:
                self.event_list.append([time.time(), 'marker_red'])
                self.Rlabel.setVisible(True)
                self.Rlabel.setStyleSheet('background-color: rgb(128, 128, 128); border: 2px solid rgb(255, 0, 0)')
            elif self.marker_list[self.i] == 2:
                self.event_list.append([time.time(), 'marker_green'])
                self.Glabel.setVisible(True)
                self.Glabel.setStyleSheet('background-color: rgb(128, 128, 128); border: 2px solid rgb(0, 255, 0)')
            elif self.marker_list[self.i] == 3:
                self.event_list.append([time.time(), 'marker_blue'])
                self.Blabel.setVisible(True)
                self.Blabel.setStyleSheet('background-color: rgb(128, 128, 128); border: 2px solid rgb(0, 0, 255)')

    def rest(self):
        self.event_list.append([time.time(), 'rest'])
        if _TEST == False:
            egi_connect(rest)   # Sending rest marker
        self.Flabel.setVisible(False)
        self.Rlabel.setVisible(False)
        self.Glabel.setVisible(False)
        self.Blabel.setVisible(False)
        self.rest_timer.singleShot(rest_duration, self.fixation)

    def trial(self):
        self.Flabel.setVisible(False)
        self.trial_timer.singleShot(trial_duration, self.rest)
        self.Flabel.setVisible(False)
        if not self.Rlabel.isVisible():
            self.Rlabel.setVisible(True)
        if not self.Glabel.isVisible():
            self.Glabel.setVisible(True)
        if not self.Blabel.isVisible():
            self.Blabel.setVisible(True)
        self.tricolor()

    def tricolor(self):
        self.Flabel.setVisible(False)
        
        if self.i < len(self.marker_list):
            if self.marker_list[self.i] == 1:
                if _TEST == False:
                    egi_connect(red)
                self.event_list.append([time.time(), 'red'])
                self.Rlabel.setStyleSheet('background-color: rgb(255, 0, 0)')
            elif self.marker_list[self.i] == 2:
                if _TEST == False:
                    egi_connect(green)
                self.event_list.append([time.time(), 'green'])
                self.Glabel.setStyleSheet('background-color: rgb(0, 255, 0)')
            elif self.marker_list[self.i] == 3:
                if _TEST == False:
                    egi_connect(blue)
                self.event_list.append([time.time(), 'blue'])
                self.Blabel.setStyleSheet('background-color: rgb(0, 0, 255)')

            self.i = self.i + 1
        else:
            print("Experiment Completed.....")
            # open file in write mode
            self.event_list.append([time.time(), 'end'])
            with open(self.filename, 'w') as fp:
                for item in self.event_list:
                    # print(item)
                    # write each item on a new line
                    fp.write("%s,%s\n" % (str(item[0]), item[1]))
            fp.close()
            print(self.event_list)
            if _TEST == False:
                egi_connect(stop)
                print("Recording Stopped.....")
                egi_connect(2)
                print("Amplifier Stopped.....")
                egi_connect(3)
            sys.exit()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    demo = Color()
    if _TEST == False:
        print("Amplifier Started.....")
        egi_connect(0)
    display_monitor = 1
    monitor = QDesktopWidget().screenGeometry(display_monitor)
    demo.move(monitor.left(), monitor.top())
    demo.showFullScreen()
    ret = app.exec_()
    if _TEST == False:
        egi_connect(2)
        print("Recording Stopped Manually.....")
        egi_connect(3)
        print("Amplifier Stopped Manually.....")
    sys.exit(ret)
