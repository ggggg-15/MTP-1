import requests

ip = "http://10.10.10.42:8080/"

def egi_connect(val):
    if val == 0:
        x = requests.get(ip + "start")
    elif val == 1:
        x = requests.get(ip + "startrec")
    elif val == 2:
        x = requests.get(ip + "stoprec")
    elif val == 3:
        x = requests.get(ip + "/stop")
    else:
        x = requests.get(ip + "send?event_type=" + val)
    print(x.content)